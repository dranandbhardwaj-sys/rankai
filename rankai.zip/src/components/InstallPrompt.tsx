"use client";

import { useEffect, useState } from "react";
import { Download, X } from "lucide-react";

export default function InstallPrompt() {
  const [deferred, setDeferred] = useState<any>(null);
  const [show, setShow] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    const ua = navigator.userAgent || "";
    const ios = /iPad|iPhone|iPod/.test(ua);
    setIsIOS(ios);

    // Already installed?
    if (window.matchMedia("(display-mode: standalone)").matches) {
      return;
    }

    const dismissed = localStorage.getItem("rankai_install_dismissed");
    if (dismissed) return;

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferred(e);
      setShow(true);
    };

    window.addEventListener("beforeinstallprompt", handler);

    // iOS: show manual instructions after short delay
    if (ios) {
      const t = setTimeout(() => setShow(true), 3000);
      return () => {
        clearTimeout(t);
        window.removeEventListener("beforeinstallprompt", handler);
      };
    }

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const install = async () => {
    if (!deferred) return;
    deferred.prompt();
    const { outcome } = await deferred.userChoice;
    if (outcome === "accepted") setShow(false);
    setDeferred(null);
  };

  const dismiss = () => {
    setShow(false);
    localStorage.setItem("rankai_install_dismissed", "1");
  };

  if (!show) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 left-3 right-3 sm:left-auto sm:right-6 sm:max-w-sm z-[60] animate-in">
      <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-xl flex gap-3 items-start">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shrink-0">
          <Download className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm mb-0.5">Install RankAI</div>
          {isIOS ? (
            <p className="text-xs text-slate-300 leading-relaxed">
              Safari mein Share → <strong>Add to Home Screen</strong> dabao
            </p>
          ) : (
            <p className="text-xs text-slate-300 leading-relaxed">
              Home screen pe app ki tarah use karo
            </p>
          )}
          <div className="flex gap-2 mt-3">
            {!isIOS && deferred && (
              <button
                onClick={install}
                className="bg-blue-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg hover:bg-blue-500"
              >
                Install
              </button>
            )}
            <button
              onClick={dismiss}
              className="text-xs text-slate-400 hover:text-white px-2 py-1.5"
            >
              Later
            </button>
          </div>
        </div>
        <button onClick={dismiss} className="text-slate-400 hover:text-white p-0.5">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
