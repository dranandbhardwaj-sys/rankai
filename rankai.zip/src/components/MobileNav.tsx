"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  TrendingUp,
  Target,
  BookOpen,
  MessageSquare,
  ClipboardList,
} from "lucide-react";

const items = [
  { href: "/dashboard", icon: TrendingUp, label: "Home" },
  { href: "/dashboard/plan", icon: Target, label: "Plan" },
  { href: "/dashboard/practice", icon: BookOpen, label: "Practice" },
  { href: "/dashboard/doubt", icon: MessageSquare, label: "Doubt" },
  { href: "/dashboard/mocks", icon: ClipboardList, label: "Mocks" },
];

export default function MobileNav() {
  const pathname = usePathname();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-50 safe-bottom">
      <div className="flex items-center justify-around h-16 px-1">
        {items.map((item) => {
          const active =
            pathname === item.href ||
            (item.href !== "/dashboard" && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center flex-1 h-full gap-0.5 ${
                active ? "text-blue-600" : "text-slate-400"
              }`}
            >
              <item.icon className={`w-5 h-5 ${active ? "stroke-[2.5]" : ""}`} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
