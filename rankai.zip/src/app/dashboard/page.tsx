"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Brain,
  BookOpen,
  Target,
  MessageSquare,
  ClipboardList,
  TrendingUp,
  Clock,
  ChevronRight,
  Flame,
  Crown,
} from "lucide-react";

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const saved = localStorage.getItem("rankai_user");
    if (saved) setUser(JSON.parse(saved));
    else
      setUser({
        exam: "jee_main",
        classLevel: "12",
        hours: 4,
        targetScore: "200",
      });
  }, []);

  const examLabel =
    user?.exam === "neet"
      ? "NEET"
      : user?.exam === "jee_advanced"
      ? "JEE Advanced"
      : "JEE Main";

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="flex">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex w-64 bg-white border-r border-slate-200 min-h-screen flex-col shrink-0">
          <div className="p-5 border-b">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Brain className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-lg">RankAI</span>
            </div>
          </div>
          <nav className="flex-1 p-3 space-y-1">
            {[
              { href: "/dashboard", icon: TrendingUp, label: "Dashboard", active: true },
              { href: "/dashboard/plan", icon: Target, label: "Study Plan" },
              { href: "/dashboard/practice", icon: BookOpen, label: "Practice" },
              { href: "/dashboard/mocks", icon: ClipboardList, label: "Mock Tests" },
              { href: "/dashboard/doubt", icon: MessageSquare, label: "Ask Doubt" },
              { href: "/pricing", icon: Crown, label: "Upgrade Pro" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                  item.active
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="p-3 border-t">
            <Link
              href="/admin/payments"
              className="text-xs text-slate-400 hover:text-slate-600 px-3"
            >
              Admin · Payments
            </Link>
          </div>
        </aside>

        {/* Main */}
        <main className="flex-1 min-w-0">
          {/* Top bar */}
          <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between sticky top-0 z-20">
            <div className="min-w-0">
              <div className="flex items-center gap-2 md:hidden mb-0.5">
                <div className="w-7 h-7 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center shrink-0">
                  <Brain className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="font-bold text-base">RankAI</span>
              </div>
              <h1 className="font-semibold text-slate-900 text-sm sm:text-base hidden md:block">
                Dashboard
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 truncate">
                {examLabel} • Class{" "}
                {user?.classLevel === "dropper" ? "Dropper" : user?.classLevel}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <div className="flex items-center gap-1.5 bg-orange-50 text-orange-700 px-2.5 py-1 rounded-full text-xs font-medium">
                <Flame className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">5 day</span> streak
              </div>
              <Link
                href="/pricing"
                className="hidden sm:flex items-center gap-1 bg-blue-600 text-white text-xs font-medium px-3 py-1.5 rounded-full hover:bg-blue-700"
              >
                <Crown className="w-3.5 h-3.5" />
                Pro
              </Link>
            </div>
          </header>

          <div className="p-4 sm:p-6 max-w-5xl">
            {/* Stats - 2x2 on mobile, 4 on desktop */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6 sm:mb-8">
              {[
                { label: "Today's Progress", value: "2.5 / 4 hrs", sub: "62%" },
                { label: "Questions Solved", value: "148", sub: "This week" },
                { label: "Accuracy", value: "71%", sub: "+4% vs last week" },
                {
                  label: "Target Score",
                  value: user?.targetScore || "—",
                  sub: examLabel,
                },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="bg-white border border-slate-200 rounded-xl p-3 sm:p-4"
                >
                  <div className="text-[11px] sm:text-sm text-slate-500 mb-0.5 sm:mb-1 truncate">
                    {stat.label}
                  </div>
                  <div className="text-lg sm:text-2xl font-bold text-slate-900">
                    {stat.value}
                  </div>
                  <div className="text-[10px] sm:text-xs text-slate-400 mt-0.5">
                    {stat.sub}
                  </div>
                </div>
              ))}
            </div>

            {/* Today's Plan */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 mb-4 sm:mb-6">
              <div className="flex items-center justify-between mb-3 sm:mb-4">
                <h2 className="font-semibold text-base sm:text-lg text-slate-900">
                  Today's Study Plan
                </h2>
                <Link
                  href="/dashboard/plan"
                  className="text-xs sm:text-sm text-blue-600 font-medium flex items-center gap-0.5"
                >
                  Full plan <ChevronRight className="w-3.5 h-3.5" />
                </Link>
              </div>
              <div className="space-y-2.5 sm:space-y-3">
                {[
                  {
                    subject: "Physics",
                    topic: "Current Electricity - Kirchhoff's Laws",
                    time: "45 min",
                    type: "Concept + Practice",
                    done: true,
                  },
                  {
                    subject: "Chemistry",
                    topic: "Chemical Kinetics - Order of Reaction",
                    time: "40 min",
                    type: "Practice",
                    done: false,
                  },
                  {
                    subject: "Maths/Bio",
                    topic: "Revision: Previous weak topics",
                    time: "30 min",
                    type: "Revision",
                    done: false,
                  },
                  {
                    subject: "Mixed",
                    topic: "Mini Mock - 15 Questions",
                    time: "25 min",
                    type: "Test",
                    done: false,
                  },
                ].map((task, i) => (
                  <div
                    key={i}
                    className={`flex items-center gap-3 p-2.5 sm:p-3 rounded-xl border ${
                      task.done
                        ? "bg-green-50 border-green-200"
                        : "bg-slate-50 border-slate-200"
                    }`}
                  >
                    <div
                      className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full border-2 flex items-center justify-center text-xs shrink-0 ${
                        task.done
                          ? "bg-green-500 border-green-500 text-white"
                          : "border-slate-300"
                      }`}
                    >
                      {task.done && "✓"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-slate-900 text-xs sm:text-sm truncate">
                        {task.topic}
                      </div>
                      <div className="text-[10px] sm:text-xs text-slate-500">
                        {task.subject} • {task.type}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] sm:text-sm text-slate-500 shrink-0">
                      <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                      {task.time}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions - horizontal scroll on very small screens */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
              {[
                {
                  href: "/dashboard/doubt",
                  icon: MessageSquare,
                  title: "Ask a Doubt",
                  desc: "Instant step-by-step solutions in Hinglish",
                },
                {
                  href: "/dashboard/practice",
                  icon: BookOpen,
                  title: "Practice Now",
                  desc: "Adaptive questions based on weak areas",
                },
                {
                  href: "/dashboard/mocks",
                  icon: ClipboardList,
                  title: "Take Mock Test",
                  desc: "Full-length tests with detailed analysis",
                },
              ].map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 hover:border-blue-300 hover:shadow-sm transition"
                >
                  <item.icon className="w-7 h-7 sm:w-8 sm:h-8 text-blue-600 mb-2 sm:mb-3" />
                  <h3 className="font-semibold text-slate-900 text-sm sm:text-base mb-0.5">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                    {item.desc}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
