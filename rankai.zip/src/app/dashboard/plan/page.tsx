"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { ArrowLeft, Clock, Target, Sparkles, Loader2, RefreshCw } from "lucide-react";

type Task = {
  type: string;
  topic: string;
  duration_minutes: number;
  priority: string;
  description: string;
};

type Plan = {
  total_hours: number;
  tasks: Task[];
  motivation_note: string;
};

export default function PlanPage() {
  const [plan, setPlan] = useState<Plan | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const generatePlan = async () => {
    setLoading(true);
    setError("");

    let userData = { exam: "jee_main", hours: 4, targetScore: "200" };
    try {
      const saved = localStorage.getItem("rankai_user");
      if (saved) userData = { ...userData, ...JSON.parse(saved) };
    } catch {}

    try {
      const res = await fetch("/api/ai/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          hours: userData.hours || 4,
          exam: userData.exam,
          targetScore: userData.targetScore,
          weakTopics: ["Current Electricity", "Chemical Kinetics"],
          strongTopics: ["Optics", "Organic Chemistry"],
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to generate plan");

      setPlan(data);
    } catch (err: any) {
      setError(err.message);
      // Fallback plan
      setPlan({
        total_hours: 4,
        tasks: [
          { type: "concept", topic: "Current Electricity", duration_minutes: 50, priority: "high", description: "Kirchhoff laws + numericals" },
          { type: "practice", topic: "Chemical Kinetics", duration_minutes: 40, priority: "high", description: "15 practice questions" },
          { type: "revision", topic: "Previous mistakes", duration_minutes: 30, priority: "medium", description: "Error notebook review" },
          { type: "mock", topic: "Mini test", duration_minutes: 25, priority: "medium", description: "15 mixed questions" },
        ],
        motivation_note: "Consistency is the key. Aaj ka plan complete karo!",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generatePlan();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="p-2 hover:bg-slate-100 rounded-lg transition">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </Link>
          <div>
            <div className="font-semibold text-sm">Personalized Study Plan</div>
            <div className="text-xs text-slate-500">AI-generated for you</div>
          </div>
        </div>
        <button
          onClick={generatePlan}
          disabled={loading}
          className="flex items-center gap-1.5 text-sm text-blue-600 font-medium hover:bg-blue-50 px-3 py-1.5 rounded-lg transition disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          Regenerate
        </button>
      </header>

      <div className="max-w-2xl mx-auto p-6">
        {loading && !plan && (
          <div className="flex flex-col items-center justify-center py-20 text-slate-500">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600 mb-3" />
            <p className="text-sm">AI aapka personal plan bana raha hai...</p>
          </div>
        )}

        {error && (
          <div className="bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-xl p-4 mb-4">
            {error} — Showing fallback plan.
          </div>
        )}

        {plan && (
          <>
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl p-5 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5" />
                <span className="font-semibold">AI Insight</span>
              </div>
              <p className="text-blue-100 text-sm leading-relaxed">
                {plan.motivation_note}
              </p>
              <div className="mt-3 text-xs text-blue-200">
                Total focused time: ~{plan.total_hours} hours
              </div>
            </div>

            <h2 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Target className="w-4 h-4 text-blue-600" />
              Today's Plan
            </h2>

            <div className="space-y-3">
              {plan.tasks.map((task, i) => (
                <div
                  key={i}
                  className="bg-white border border-slate-200 rounded-xl p-4 flex items-start gap-4 hover:shadow-sm transition"
                >
                  <div className="bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-1.5 rounded-lg flex items-center gap-1 shrink-0">
                    <Clock className="w-3 h-3" />
                    {task.duration_minutes}m
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm text-slate-900">
                      {task.topic}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {task.description}
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded capitalize">
                        {task.type}
                      </span>
                      <span
                        className={`text-xs px-1.5 py-0.5 rounded ${
                          task.priority === "high"
                            ? "bg-red-50 text-red-600"
                            : task.priority === "medium"
                            ? "bg-amber-50 text-amber-600"
                            : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {task.priority}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
