"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { Brain, Send, ArrowLeft, Loader2, Sparkles, History } from "lucide-react";

type Message = {
  role: "user" | "assistant";
  content: string;
};

export default function DoubtPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Namaste! 👋 Main RankAI hoon — aapka personal JEE/NEET mentor.\n\nKoi bhi Physics, Chemistry, Maths ya Biology ka doubt poochho. Main Hinglish mein step-by-step samjhaunga.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const loadHistory = async () => {
    try {
      const res = await fetch("/api/doubts");
      const data = await res.json();
      setHistory(data.doubts || []);
      setShowHistory(true);
    } catch {
      setHistory([]);
      setShowHistory(true);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);

    let exam = "jee_main";
    try {
      const saved = localStorage.getItem("rankai_user");
      if (saved) exam = JSON.parse(saved).exam || "jee_main";
    } catch {}

    try {
      const res = await fetch("/api/ai/doubt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: userMsg, exam }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");

      const answer = data.answer;
      setMessages((prev) => [...prev, { role: "assistant", content: answer }]);

      // Save to doubt history (non-blocking)
      fetch("/api/doubts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: userMsg,
          answer,
          exam_type: exam,
        }),
      }).catch(() => {});
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `⚠️ Error: ${err.message}\n\nAPI key check karo ya phir se try karo.`,
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const suggestions = [
    "Kirchhoff's law kaise apply kare?",
    "First order reaction ka half life kya hota hai?",
    "Neuron mein impulse transmission explain karo",
    "Integration by parts ka formula with example",
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="p-2 hover:bg-slate-100 rounded-lg transition">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <Brain className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="font-semibold text-sm">AI Doubt Solver</div>
              <div className="text-xs text-green-600 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                Online
              </div>
            </div>
          </div>
        </div>
        <button
          onClick={loadHistory}
          className="p-2 hover:bg-slate-100 rounded-lg text-slate-500"
          title="Doubt History"
        >
          <History className="w-5 h-5" />
        </button>
      </header>

      {/* History Panel */}
      {showHistory && (
        <div className="bg-white border-b border-slate-200 p-4 max-h-48 overflow-y-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">Recent Doubts</span>
            <button
              onClick={() => setShowHistory(false)}
              className="text-xs text-slate-500 hover:text-slate-700"
            >
              Close
            </button>
          </div>
          {history.length === 0 ? (
            <p className="text-xs text-slate-400">
              No history yet. Login karke doubts poocho — save ho jayenge.
            </p>
          ) : (
            <div className="space-y-2">
              {history.slice(0, 5).map((d) => (
                <button
                  key={d.id}
                  onClick={() => {
                    setInput(d.question);
                    setShowHistory(false);
                  }}
                  className="block w-full text-left text-xs text-slate-600 hover:text-blue-600 truncate"
                >
                  {d.question}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 max-w-3xl mx-auto w-full space-y-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                msg.role === "user"
                  ? "bg-blue-600 text-white rounded-br-md"
                  : "bg-white border border-slate-200 text-slate-800 rounded-bl-md shadow-sm"
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.content}</div>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-200 rounded-2xl px-4 py-3 flex items-center gap-2 text-sm text-slate-500 shadow-sm">
              <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
              Soch raha hoon...
            </div>
          </div>
        )}

        {messages.length <= 1 && !loading && (
          <div className="pt-2">
            <p className="text-xs text-slate-400 mb-2 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Try asking
            </p>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => setInput(s)}
                  className="text-xs bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded-full hover:border-blue-300 hover:text-blue-600 transition"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      <div className="border-t bg-white p-4">
        <div className="max-w-3xl mx-auto flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder="Apna doubt yahan likho... (Hinglish chalega)"
            className="flex-1 border border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={loading}
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition shrink-0"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
