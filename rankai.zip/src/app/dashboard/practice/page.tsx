"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  CheckCircle,
  XCircle,
  ChevronRight,
  Loader2,
  BookOpen,
} from "lucide-react";

type Question = {
  id: number;
  question_text: string;
  options: Record<string, string>;
  correct_option: string;
  explanation: string;
  subject?: string;
  topic?: string;
  difficulty?: string;
};

export default function PracticePage() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [source, setSource] = useState("");

  useEffect(() => {
    async function load() {
      try {
        let exam = "jee_main";
        try {
          const saved = localStorage.getItem("rankai_user");
          if (saved) exam = JSON.parse(saved).exam || "jee_main";
        } catch {}

        const res = await fetch(`/api/questions?limit=8&exam=${exam}`);
        const data = await res.json();
        setQuestions(data.questions || []);
        setSource(data.source || "");
      } catch {
        setQuestions([]);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-3" />
          <p className="text-sm text-slate-500">Loading questions...</p>
        </div>
      </div>
    );
  }

  if (!questions.length) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-600 mb-4">No questions available yet.</p>
          <Link href="/dashboard" className="text-blue-600 font-medium">
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  const q = questions[current];
  const optionKeys = Object.keys(q.options || {});

  const handleSelect = (key: string) => {
    if (showResult) return;
    setSelected(key);
    setShowResult(true);
    if (key === q.correct_option) setScore((s) => s + 1);
  };

  const handleNext = () => {
    if (current < questions.length - 1) {
      setCurrent(current + 1);
      setSelected(null);
      setShowResult(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="p-2 hover:bg-slate-100 rounded-lg">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </Link>
          <div>
            <div className="font-semibold text-sm">Adaptive Practice</div>
            <div className="text-xs text-slate-500">
              Question {current + 1} of {questions.length}
              {source === "database" && (
                <span className="ml-2 text-green-600">• Live DB</span>
              )}
            </div>
          </div>
        </div>
        <div className="text-sm font-medium text-slate-600">
          Score: {score}/{current + (showResult ? 1 : 0)}
        </div>
      </header>

      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 mb-4">
          <div className="flex flex-wrap gap-2 mb-4">
            {q.subject && (
              <span className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-full font-medium">
                {q.subject}
              </span>
            )}
            {q.topic && (
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-full">
                {q.topic}
              </span>
            )}
            {q.difficulty && (
              <span className="text-xs bg-orange-50 text-orange-700 px-2 py-1 rounded-full capitalize">
                {q.difficulty}
              </span>
            )}
          </div>

          <h2 className="text-lg font-medium text-slate-900 mb-6 leading-relaxed">
            {q.question_text}
          </h2>

          <div className="space-y-3">
            {optionKeys.map((key) => {
              let style = "border-slate-200 hover:border-slate-300";
              if (showResult) {
                if (key === q.correct_option) style = "border-green-500 bg-green-50";
                else if (key === selected) style = "border-red-400 bg-red-50";
              } else if (selected === key) {
                style = "border-blue-500 bg-blue-50";
              }

              return (
                <button
                  key={key}
                  onClick={() => handleSelect(key)}
                  className={`w-full text-left p-4 rounded-xl border-2 transition flex items-center gap-3 ${style}`}
                >
                  <span className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-sm font-medium shrink-0">
                    {key}
                  </span>
                  <span className="flex-1">{q.options[key]}</span>
                  {showResult && key === q.correct_option && (
                    <CheckCircle className="w-5 h-5 text-green-600 shrink-0" />
                  )}
                  {showResult && key === selected && key !== q.correct_option && (
                    <XCircle className="w-5 h-5 text-red-500 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {showResult && (
            <div className="mt-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="font-medium text-sm mb-1">Explanation</div>
              <p className="text-sm text-slate-600 leading-relaxed">{q.explanation}</p>
            </div>
          )}
        </div>

        {showResult && (
          <div className="flex justify-between items-center">
            <div className="text-sm text-slate-600">
              {selected === q.correct_option ? (
                <span className="text-green-600 font-medium">Correct!</span>
              ) : (
                <span className="text-red-500 font-medium">Incorrect</span>
              )}
            </div>
            {current < questions.length - 1 ? (
              <button
                onClick={handleNext}
                className="bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-blue-700 flex items-center gap-1"
              >
                Next Question
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <Link
                href="/dashboard"
                className="bg-green-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-green-700"
              >
                Finish • {score}/{questions.length}
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
