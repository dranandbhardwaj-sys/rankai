"use client";

import Link from "next/link";
import { ArrowLeft, ClipboardList, Clock, BarChart3, Play } from "lucide-react";

const MOCKS = [
  {
    id: 1,
    title: "JEE Main Full Mock #12",
    questions: 90,
    duration: "3 hours",
    subjects: "PCM",
    difficulty: "Moderate",
    attempted: false,
  },
  {
    id: 2,
    title: "Physics Chapter Test - Current Electricity",
    questions: 30,
    duration: "45 min",
    subjects: "Physics",
    difficulty: "Hard",
    attempted: true,
    score: 22,
  },
  {
    id: 3,
    title: "NEET Biology Mini Mock",
    questions: 45,
    duration: "45 min",
    subjects: "Biology",
    difficulty: "Moderate",
    attempted: false,
  },
  {
    id: 4,
    title: "Previous Year - JEE Main 2024 Jan",
    questions: 90,
    duration: "3 hours",
    subjects: "PCM",
    difficulty: "Real",
    attempted: true,
    score: 168,
  },
];

export default function MocksPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center gap-3">
        <Link href="/dashboard" className="p-2 hover:bg-slate-100 rounded-lg">
          <ArrowLeft className="w-5 h-5 text-slate-600" />
        </Link>
        <div>
          <div className="font-semibold text-sm">Mock Tests</div>
          <div className="text-xs text-slate-500">Practice under real exam conditions</div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto p-6 space-y-4">
        {MOCKS.map((mock) => (
          <div
            key={mock.id}
            className="bg-white border border-slate-200 rounded-2xl p-5 hover:shadow-sm transition"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <h3 className="font-semibold text-slate-900 mb-1">{mock.title}</h3>
                <div className="flex flex-wrap gap-3 text-sm text-slate-500 mb-3">
                  <span className="flex items-center gap-1">
                    <ClipboardList className="w-3.5 h-3.5" />
                    {mock.questions} Qs
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {mock.duration}
                  </span>
                  <span className="bg-slate-100 px-2 py-0.5 rounded text-xs">
                    {mock.subjects}
                  </span>
                  <span className="bg-orange-50 text-orange-700 px-2 py-0.5 rounded text-xs">
                    {mock.difficulty}
                  </span>
                </div>

                {mock.attempted && (
                  <div className="flex items-center gap-2 text-sm">
                    <BarChart3 className="w-4 h-4 text-green-600" />
                    <span className="text-green-700 font-medium">
                      Score: {mock.score}
                      {mock.questions === 90 ? "/300" : `/${mock.questions}`}
                    </span>
                  </div>
                )}
              </div>

              <button className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-blue-700 flex items-center gap-1.5 shrink-0">
                <Play className="w-4 h-4" />
                {mock.attempted ? "Re-attempt" : "Start"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
