import MobileNav from "@/components/MobileNav";
import InstallPrompt from "@/components/InstallPrompt";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-slate-50">
      {children}
      <MobileNav />
      <InstallPrompt />
      {/* Spacer so content isn't hidden behind bottom nav on mobile */}
      <div className="h-16 md:hidden" />
    </div>
  );
}
