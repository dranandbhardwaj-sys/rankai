"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Brain, ChevronRight, ChevronLeft, Loader2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    exam: "",
    classLevel: "",
    hours: 4,
    targetScore: "",
  });

  const handleFinish = async () => {
    setLoading(true);

    const payload = {
      exam_type: form.exam,
      class_level: form.classLevel,
      daily_study_hours: form.hours,
      target_score: Number(form.targetScore) || null,
      onboarding_completed: true,
    };

    // Always save to localStorage as fallback
    localStorage.setItem(
      "rankai_user",
      JSON.stringify({
        exam: form.exam,
        classLevel: form.classLevel,
        hours: form.hours,
        targetScore: form.targetScore,
      })
    );

    try {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();

      if (user) {
        await supabase
          .from("profiles")
          .update(payload)
          .eq("id", user.id);
      }
    } catch {
      // Supabase not configured – localStorage is enough for demo
    }

    setLoading(false);
    router.push("/dashboard");
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 w-full max-w-lg p-8">
        <div className="flex items-center gap-2 mb-8">
          <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-xl">RankAI</span>
        </div>

        {/* Progress */}
        <div className="flex gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-1.5 flex-1 rounded-full transition-colors ${
                s <= step ? "bg-blue-600" : "bg-slate-200"
              }`}
            />
          ))}
        </div>

        {step === 1 && (
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Select your exam</h2>
            <p className="text-slate-600 mb-6">We will personalize everything for you</p>
            <div className="space-y-3">
              {[
                { id: "jee_main", label: "JEE Main", desc: "Physics, Chemistry, Maths" },
                { id: "jee_advanced", label: "JEE Advanced", desc: "For IIT aspirants" },
                { id: "neet", label: "NEET", desc: "Physics, Chemistry, Biology" },
              ].map((exam) => (
                <button
                  key={exam.id}
                  onClick={() => setForm({ ...form, exam: exam.id })}
                  className={`w-full text-left p-4 rounded-xl border-2 transition ${
                    form.exam === exam.id
                      ? "border-blue-600 bg-blue-50"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="font-semibold text-slate-900">{exam.label}</div>
                  <div className="text-sm text-slate-500">{exam.desc}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Your current level</h2>
            <p className="text-slate-600 mb-6">This helps us set the right difficulty</p>
            <div className="space-y-3 mb-6">
              {[
                { id: "11", label: "Class 11" },
                { id: "12", label: "Class 12" },
                { id: "dropper", label: "Dropper / Repeater" },
              ].map((level) => (
                <button
                  key={level.id}
                  onClick={() => setForm({ ...form, classLevel: level.id })}
                  className={`w-full text-left p-4 rounded-xl border-2 transition ${
                    form.classLevel === level.id
                      ? "border-blue-600 bg-blue-50"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="font-semibold text-slate-900">{level.label}</div>
                </button>
              ))}
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Daily study hours available
              </label>
              <input
                type="range"
                min="1"
                max="10"
                value={form.hours}
                onChange={(e) => setForm({ ...form, hours: Number(e.target.value) })}
                className="w-full accent-blue-600"
              />
              <div className="text-center mt-2 font-semibold text-blue-600">
                {form.hours} hours / day
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Your target</h2>
            <p className="text-slate-600 mb-6">What score are you aiming for?</p>
            <input
              type="number"
              placeholder={form.exam === "neet" ? "e.g. 650" : "e.g. 200"}
              value={form.targetScore}
              onChange={(e) => setForm({ ...form, targetScore: e.target.value })}
              className="w-full border border-slate-300 rounded-xl px-4 py-3 text-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="text-sm text-slate-500 mt-3">
              {form.exam === "neet"
                ? "NEET total marks: 720"
                : "JEE Main total marks: 300"}
            </p>
          </div>
        )}

        {/* Navigation */}
        <div className="flex justify-between mt-8">
          {step > 1 ? (
            <button
              onClick={() => setStep(step - 1)}
              className="flex items-center gap-1 text-slate-600 hover:text-slate-900"
            >
              <ChevronLeft className="w-4 h-4" />
              Back
            </button>
          ) : (
            <div />
          )}

          {step < 3 ? (
            <button
              onClick={() => setStep(step + 1)}
              disabled={
                (step === 1 && !form.exam) ||
                (step === 2 && !form.classLevel)
              }
              className="bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              Continue
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleFinish}
              disabled={!form.targetScore || loading}
              className="bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              Start Learning
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
