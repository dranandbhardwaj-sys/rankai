"use client";

import Link from "next/link";
import { BookOpen, Brain, Target, TrendingUp, Zap, ChevronRight } from "lucide-react";
import InstallPrompt from "@/components/InstallPrompt";

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <InstallPrompt />
      {/* Navbar */}
      <nav className="border-b bg-white/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-14 sm:h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
            <span className="font-bold text-lg sm:text-xl text-slate-900">RankAI</span>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              href="/login"
              className="text-sm font-medium text-slate-600 hover:text-slate-900 px-2 py-2"
            >
              Login
            </Link>
            <Link
              href="/onboarding"
              className="bg-blue-600 text-white px-3 sm:px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-4 pt-10 sm:pt-16 pb-12 sm:pb-20">
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs sm:text-sm font-medium mb-4 sm:mb-6">
            <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            AI-Powered JEE & NEET Preparation
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 leading-tight mb-4 sm:mb-6">
            Your Personal AI Mentor for{" "}
            <span className="text-blue-600">JEE & NEET</span>
          </h1>
          <p className="text-base sm:text-lg text-slate-600 mb-6 sm:mb-8 px-1">
            Personalized study plans, instant doubt solving in Hinglish,
            adaptive practice, and smart mock analysis.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/onboarding"
              className="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2"
            >
              Start Free Now
              <ChevronRight className="w-4 h-4" />
            </Link>
            <Link
              href="/dashboard"
              className="border border-slate-300 bg-white text-slate-700 px-6 py-3 rounded-xl font-semibold hover:bg-slate-50 transition"
            >
              View Demo Dashboard
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-4 pb-12 sm:pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {[
            {
              icon: Brain,
              title: "AI Doubt Solver",
              desc: "Ask any question in Hinglish. Get step-by-step solutions with common mistakes highlighted.",
            },
            {
              icon: Target,
              title: "Personalized Plan",
              desc: "Daily study plan based on your weak topics, available hours, and target score.",
            },
            {
              icon: BookOpen,
              title: "Adaptive Practice",
              desc: "Questions that adapt to your level. Focus more on weak areas automatically.",
            },
            {
              icon: TrendingUp,
              title: "Smart Analysis",
              desc: "Detailed mock test analysis with 7-day improvement roadmap.",
            },
          ].map((f) => (
            <div
              key={f.title}
              className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 hover:shadow-md transition"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 bg-blue-50 rounded-xl flex items-center justify-center mb-3 sm:mb-4">
                <f.icon className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="font-semibold text-slate-900 mb-1.5 sm:mb-2">{f.title}</h3>
              <p className="text-sm text-slate-600 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-12 sm:py-16">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">
            Ready to improve your rank?
          </h2>
          <p className="text-blue-100 mb-6 sm:mb-8 text-sm sm:text-base">
            Join thousands of aspirants using AI to study smarter, not harder.
          </p>
          <Link
            href="/onboarding"
            className="inline-flex items-center gap-2 bg-white text-blue-600 px-6 py-3 rounded-xl font-semibold hover:bg-blue-50 transition"
          >
            Create Free Account
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      <footer className="border-t bg-white py-6 sm:py-8">
        <div className="max-w-6xl mx-auto px-4 text-center text-xs sm:text-sm text-slate-500">
          © 2026 RankAI • Built for JEE & NEET aspirants
        </div>
      </footer>
    </div>
  );
}
