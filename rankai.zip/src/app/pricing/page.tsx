"use client";

import { useState } from "react";
import Link from "next/link";
import {
  Brain,
  Check,
  Loader2,
  ArrowLeft,
  Zap,
  Copy,
  CheckCircle2,
  Smartphone,
} from "lucide-react";

declare global {
  interface Window {
    Razorpay: any;
  }
}

const UPI_ID = "9162172649@ybl";
const UPI_NAME = "RankAI";

const PLANS = [
  {
    id: "pro_monthly",
    name: "Pro Monthly",
    price: 499,
    period: "/month",
    features: [
      "Unlimited AI doubts",
      "Unlimited mock tests",
      "Personalized study plans",
      "Detailed performance analysis",
      "Priority support",
    ],
    popular: false,
  },
  {
    id: "pro_quarterly",
    name: "Pro Quarterly",
    price: 1199,
    period: "/3 months",
    features: [
      "Everything in Monthly",
      "Save ₹298",
      "Exam-specific crash tips",
      "Weak topic prioritization",
      "Progress reports",
    ],
    popular: true,
  },
  {
    id: "crash_30",
    name: "30-Day Crash",
    price: 1499,
    period: "one-time",
    features: [
      "Intensive 30-day plan",
      "Daily AI mentor check-ins",
      "Full test series access",
      "Last-minute revision mode",
      "Rank prediction",
    ],
    popular: false,
  },
];

export default function PricingPage() {
  const [loading, setLoading] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [paidConfirm, setPaidConfirm] = useState(false);
  const [txnNote, setTxnNote] = useState("");

  const selected = PLANS.find((p) => p.id === selectedPlan);

  const copyUpi = async () => {
    try {
      await navigator.clipboard.writeText(UPI_ID);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
      const el = document.createElement("textarea");
      el.value = UPI_ID;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const openUpiApp = () => {
    if (!selected) return;
    // UPI deep link – works on many Android UPI apps
    const amount = selected.price;
    const note = encodeURIComponent(`RankAI ${selected.name}`);
    const upiUrl = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(
      UPI_NAME
    )}&am=${amount}&cu=INR&tn=${note}`;
    window.location.href = upiUrl;
  };

  const confirmManualPayment = async () => {
    if (!selected) return;

    let email = "";
    let fullName = "";
    try {
      const saved = localStorage.getItem("rankai_user");
      if (saved) {
        const u = JSON.parse(saved);
        email = u.email || "";
        fullName = u.fullName || u.full_name || "";
      }
    } catch {}

    // Save claim for admin review
    try {
      await fetch("/api/payments/claims", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: selected.id,
          planName: selected.name,
          amount: selected.price,
          upiNote: txnNote || "",
          email,
          fullName,
        }),
      });
    } catch {
      // non-blocking
    }

    // Mark Pro locally until admin verifies (soft unlock)
    const proData = {
      planId: selected.id,
      planName: selected.name,
      amount: selected.price,
      activatedAt: new Date().toISOString(),
      method: "upi_manual",
      note: txnNote || "",
      status: "pending_verification",
    };
    localStorage.setItem("rankai_pro", JSON.stringify(proData));
    setPaidConfirm(true);
    setMessage(
      `Claim submit ho gaya. ${selected.name} temporarily unlock. Admin /admin/payments pe verify karega.`
    );
  };

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      if (window.Razorpay) {
        resolve(true);
        return;
      }
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handleRazorpay = async (planId: string) => {
    setLoading(planId);
    setMessage("");

    try {
      const orderRes = await fetch("/api/payments/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId }),
      });
      const order = await orderRes.json();
      if (!orderRes.ok) throw new Error(order.error || "Order failed");

      if (order.demo) {
        const verifyRes = await fetch("/api/payments/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            demo: true,
            planId,
            razorpay_order_id: order.orderId,
          }),
        });
        const verify = await verifyRes.json();
        localStorage.setItem(
          "rankai_pro",
          JSON.stringify({
            planId,
            activatedAt: new Date().toISOString(),
            method: "razorpay_demo",
          })
        );
        setMessage(verify.message || "Demo payment successful! Pro unlocked.");
        setLoading(null);
        return;
      }

      const loaded = await loadRazorpayScript();
      if (!loaded) throw new Error("Razorpay SDK failed to load");

      const options = {
        key: order.keyId,
        amount: order.amount,
        currency: order.currency,
        name: "RankAI",
        description: order.planName,
        order_id: order.orderId,
        handler: async (response: any) => {
          const verifyRes = await fetch("/api/payments/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ...response, planId, demo: false }),
          });
          const verify = await verifyRes.json();
          if (verify.success) {
            localStorage.setItem(
              "rankai_pro",
              JSON.stringify({
                planId,
                activatedAt: new Date().toISOString(),
                method: "razorpay",
                paymentId: response.razorpay_payment_id,
              })
            );
            setMessage("Payment successful! Pro features unlocked.");
          } else {
            setMessage(verify.error || "Verification failed");
          }
          setLoading(null);
        },
        theme: { color: "#2563eb" },
        modal: { ondismiss: () => setLoading(null) },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err: any) {
      setMessage(err.message || "Payment failed");
      setLoading(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center gap-3 sticky top-0 z-20">
        <Link href="/dashboard" className="p-2 hover:bg-slate-100 rounded-lg">
          <ArrowLeft className="w-5 h-5 text-slate-600" />
        </Link>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
            <Brain className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold">RankAI Pro</span>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-8 sm:py-12">
        <div className="text-center mb-8 sm:mb-10">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium mb-4">
            <Zap className="w-4 h-4" />
            Upgrade to Pro
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
            Study smarter. Rank higher.
          </h1>
          <p className="text-slate-600 max-w-lg mx-auto text-sm sm:text-base">
            Unlimited doubts, personalized plans, full mocks, and detailed analysis.
          </p>
        </div>

        {message && (
          <div className="max-w-md mx-auto mb-6 bg-green-50 border border-green-200 text-green-800 text-sm rounded-xl p-4 text-center">
            {message}
          </div>
        )}

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-4 sm:gap-6 mb-10">
          {PLANS.map((plan) => (
            <div
              key={plan.id}
              className={`bg-white rounded-2xl border-2 p-5 sm:p-6 relative ${
                plan.popular ? "border-blue-600 shadow-lg" : "border-slate-200"
              } ${selectedPlan === plan.id ? "ring-2 ring-blue-400" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                  Most Popular
                </div>
              )}

              <h3 className="font-bold text-lg text-slate-900">{plan.name}</h3>
              <div className="mt-2 mb-4">
                <span className="text-3xl font-bold text-slate-900">
                  ₹{plan.price}
                </span>
                <span className="text-slate-500 text-sm">{plan.period}</span>
              </div>

              <ul className="space-y-2 mb-5">
                {plan.features.map((f) => (
                  <li
                    key={f}
                    className="flex items-start gap-2 text-sm text-slate-600"
                  >
                    <Check className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => {
                  setSelectedPlan(plan.id);
                  setPaidConfirm(false);
                  setMessage("");
                }}
                className={`w-full py-3 rounded-xl font-semibold transition ${
                  selectedPlan === plan.id
                    ? "bg-blue-600 text-white"
                    : plan.popular
                    ? "bg-blue-600 text-white hover:bg-blue-700"
                    : "bg-slate-900 text-white hover:bg-slate-800"
                }`}
              >
                {selectedPlan === plan.id ? "Selected" : "Select Plan"}
              </button>
            </div>
          ))}
        </div>

        {/* Payment methods when plan selected */}
        {selected && (
          <div className="max-w-lg mx-auto bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5">
            <h2 className="font-semibold text-slate-900 text-center">
              Pay ₹{selected.price} for {selected.name}
            </h2>

            {/* UPI Section */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-sm font-medium text-slate-700">
                <Smartphone className="w-4 h-4 text-blue-600" />
                Pay via UPI
              </div>

              <div className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2.5">
                <code className="flex-1 text-sm font-mono text-slate-800 break-all">
                  {UPI_ID}
                </code>
                <button
                  onClick={copyUpi}
                  className="shrink-0 flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-700 px-2 py-1"
                >
                  {copied ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> Copy
                    </>
                  )}
                </button>
              </div>

              <p className="text-xs text-slate-500">
                Amount: <strong>₹{selected.price}</strong> · Note mein plan name
                likh dena (optional)
              </p>

              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  onClick={openUpiApp}
                  className="flex-1 bg-blue-600 text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition"
                >
                  Open UPI App
                </button>
                <button
                  onClick={copyUpi}
                  className="flex-1 border border-slate-300 text-slate-700 py-2.5 rounded-xl text-sm font-medium hover:bg-slate-50 transition"
                >
                  Copy UPI ID
                </button>
              </div>

              {/* After payment confirmation */}
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <label className="block text-xs text-slate-500">
                  Transaction note / UTR (optional)
                </label>
                <input
                  type="text"
                  value={txnNote}
                  onChange={(e) => setTxnNote(e.target.value)}
                  placeholder="e.g. UTR or last 4 digits"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={confirmManualPayment}
                  disabled={paidConfirm}
                  className="w-full bg-green-600 text-white py-2.5 rounded-xl text-sm font-semibold hover:bg-green-700 transition disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  {paidConfirm ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" /> Marked as Paid
                    </>
                  ) : (
                    "I have paid – Activate Pro"
                  )}
                </button>
                <p className="text-[11px] text-slate-400 text-center">
                  Manual verification: aap UPI pe payment dekh ke confirm kar
                  sakte ho. Auto-verify ke liye baad mein Razorpay laga sakte
                  ho.
                </p>
              </div>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3 text-xs text-slate-400">
              <div className="flex-1 h-px bg-slate-200" />
              OR
              <div className="flex-1 h-px bg-slate-200" />
            </div>

            {/* Razorpay */}
            <button
              onClick={() => handleRazorpay(selected.id)}
              disabled={!!loading}
              className="w-full border border-slate-300 text-slate-700 py-3 rounded-xl text-sm font-medium hover:bg-slate-50 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading === selected.id && (
                <Loader2 className="w-4 h-4 animate-spin" />
              )}
              Pay with Razorpay / Card / NetBanking
            </button>
          </div>
        )}

        <p className="text-center text-xs text-slate-400 mt-8">
          UPI: {UPI_ID} · Razorpay keys optional (demo mode available)
        </p>
      </div>
    </div>
  );
}
