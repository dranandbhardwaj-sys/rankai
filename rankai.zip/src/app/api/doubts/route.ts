import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { question, answer, exam_type, subject } = body;

    if (!question) {
      return NextResponse.json({ error: "Question required" }, { status: 400 });
    }

    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    // Save only if user is logged in
    if (user) {
      const { error } = await supabase.from("doubt_logs").insert({
        user_id: user.id,
        question,
        answer: answer || null,
        exam_type: exam_type || null,
        subject: subject || null,
      });

      if (error) {
        console.error("Doubt log error:", error);
        // Don't fail the request – just log
      }
    }

    return NextResponse.json({ success: true, saved: !!user });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message });
  }
}

export async function GET() {
  try {
    const supabase = await createClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ doubts: [], message: "Login to see history" });
    }

    const { data, error } = await supabase
      .from("doubt_logs")
      .select("id, question, answer, exam_type, subject, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) throw error;

    return NextResponse.json({ doubts: data || [] });
  } catch (err: any) {
    return NextResponse.json({ doubts: [], error: err.message });
  }
}
