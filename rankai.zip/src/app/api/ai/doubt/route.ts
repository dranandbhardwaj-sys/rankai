import { NextRequest, NextResponse } from "next/server";
import { callAI } from "@/lib/ai/client";
import { DOUBT_SYSTEM_PROMPT, buildDoubtPrompt } from "@/lib/ai/prompts";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { question, exam = "jee_main", subject } = body;

    if (!question || typeof question !== "string" || question.trim().length < 3) {
      return NextResponse.json(
        { error: "Please provide a valid question" },
        { status: 400 }
      );
    }

    const userPrompt = buildDoubtPrompt(question.trim(), exam, subject);

    const aiResponse = await callAI(
      [
        { role: "system", content: DOUBT_SYSTEM_PROMPT },
        { role: "user", content: userPrompt },
      ],
      { temperature: 0.35, maxTokens: 1800 }
    );

    return NextResponse.json({
      answer: aiResponse.content,
      model: aiResponse.model,
      provider: aiResponse.provider,
    });
  } catch (error: any) {
    console.error("Doubt API error:", error);

    // Fallback so the UI doesn't break if key is missing
    if (error.message?.includes("API_KEY")) {
      return NextResponse.json({
        answer: `⚠️ AI API key configure nahi hai.

**Demo Response:**

Aapka question mil gaya. Real AI response ke liye \`.env.local\` mein \`OPENAI_API_KEY\` ya \`ANTHROPIC_API_KEY\` add karo.

**General Approach:**
1. Concept clear karo
2. Formula / principle apply karo
3. Step-by-step solve karo
4. Common mistakes check karo

*Setup ke baad yeh real detailed answer dega.*`,
        model: "demo",
        provider: "fallback",
      });
    }

    return NextResponse.json(
      { error: error.message || "Failed to process doubt" },
      { status: 500 }
    );
  }
}
