import { NextRequest, NextResponse } from "next/server";
import { callAI } from "@/lib/ai/client";
import { PLAN_SYSTEM_PROMPT, buildPlanPrompt } from "@/lib/ai/prompts";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      hours = 4,
      weakTopics = [],
      strongTopics = [],
      exam = "jee_main",
      targetScore = "",
    } = body;

    const userPrompt = buildPlanPrompt({
      exam,
      hours: Number(hours),
      weakTopics,
      strongTopics,
      targetScore: String(targetScore),
    });

    const aiResponse = await callAI(
      [
        { role: "system", content: PLAN_SYSTEM_PROMPT },
        { role: "user", content: userPrompt },
      ],
      { temperature: 0.4, maxTokens: 1200 }
    );

    // Try to parse JSON from the response
    let plan;
    try {
      const jsonMatch = aiResponse.content.match(/\{[\s\S]*\}/);
      plan = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
    } catch {
      plan = null;
    }

    // Fallback structured plan if parsing fails
    if (!plan) {
      plan = {
        total_hours: hours,
        tasks: [
          {
            type: "concept",
            topic: weakTopics[0] || "High priority chapter",
            duration_minutes: Math.round(hours * 60 * 0.35),
            priority: "high",
            description: "Concept revision + important formulas",
          },
          {
            type: "practice",
            topic: weakTopics[0] || "High priority chapter",
            duration_minutes: Math.round(hours * 60 * 0.3),
            priority: "high",
            description: "15-20 adaptive practice questions",
          },
          {
            type: "revision",
            topic: "Previous mistakes",
            duration_minutes: Math.round(hours * 60 * 0.2),
            priority: "medium",
            description: "Quick revision of recent errors",
          },
          {
            type: "mock",
            topic: "Mini test",
            duration_minutes: Math.round(hours * 60 * 0.15),
            priority: "medium",
            description: "Short mixed quiz",
          },
        ],
        motivation_note: "Aaj ka plan realistic hai. Consistency hi rank laati hai!",
      };
    }

    return NextResponse.json({
      ...plan,
      model: aiResponse.model,
      provider: aiResponse.provider,
    });
  } catch (error: any) {
    console.error("Plan API error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to generate plan" },
      { status: 500 }
    );
  }
}
