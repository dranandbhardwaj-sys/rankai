import { NextRequest, NextResponse } from "next/server";
import { callAI } from "@/lib/ai/client";
import { ANALYSIS_SYSTEM_PROMPT } from "@/lib/ai/prompts";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { exam = "jee_main", score, total, topicBreakdown, timeTaken } = body;

    const userPrompt = `Exam: ${exam}
Score: ${score}/${total}
Time taken: ${timeTaken || "N/A"} minutes
Topic-wise performance: ${JSON.stringify(topicBreakdown || {}, null, 2)}

Please analyze and give feedback.`;

    const aiResponse = await callAI(
      [
        { role: "system", content: ANALYSIS_SYSTEM_PROMPT },
        { role: "user", content: userPrompt },
      ],
      { temperature: 0.4, maxTokens: 1500 }
    );

    return NextResponse.json({
      analysis: aiResponse.content,
      model: aiResponse.model,
      provider: aiResponse.provider,
    });
  } catch (error: any) {
    console.error("Analyze API error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to analyze mock" },
      { status: 500 }
    );
  }
}
