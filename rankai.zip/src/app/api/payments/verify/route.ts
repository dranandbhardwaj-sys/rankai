import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: NextRequest) {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      planId,
      demo,
    } = await req.json();

    // Demo mode – always succeed
    if (demo) {
      return NextResponse.json({
        success: true,
        message: "Demo payment successful. Pro unlocked!",
        planId,
      });
    }

    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keySecret) {
      return NextResponse.json({ error: "Payment not configured" }, { status: 500 });
    }

    // Verify signature
    const body = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac("sha256", keySecret)
      .update(body)
      .digest("hex");

    if (expectedSignature !== razorpay_signature) {
      return NextResponse.json({ error: "Invalid payment signature" }, { status: 400 });
    }

    // Optional: mark user as Pro in profiles
    try {
      const supabase = await createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (user) {
        // You can add a `plan` or `is_pro` column later
        await supabase.from("profiles").update({
          updated_at: new Date().toISOString(),
          // is_pro: true, plan: planId  ← add these columns when ready
        }).eq("id", user.id);
      }
    } catch {
      // non-blocking
    }

    return NextResponse.json({
      success: true,
      message: "Payment verified. Pro unlocked!",
      planId,
      paymentId: razorpay_payment_id,
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || "Verification failed" },
      { status: 500 }
    );
  }
}
