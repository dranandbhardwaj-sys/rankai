import { NextRequest, NextResponse } from "next/server";

/**
 * Create Razorpay Order
 * Docs: https://razorpay.com/docs/api/orders/
 *
 * Required env:
 * RAZORPAY_KEY_ID=
 * RAZORPAY_KEY_SECRET=
 */

const PLANS: Record<string, { amount: number; name: string }> = {
  pro_monthly: { amount: 49900, name: "RankAI Pro Monthly" }, // ₹499 in paise
  pro_quarterly: { amount: 119900, name: "RankAI Pro Quarterly" }, // ₹1199
  crash_30: { amount: 149900, name: "RankAI 30-Day Crash" }, // ₹1499
};

export async function POST(req: NextRequest) {
  try {
    const { planId } = await req.json();
    const plan = PLANS[planId];

    if (!plan) {
      return NextResponse.json({ error: "Invalid plan" }, { status: 400 });
    }

    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;

    if (!keyId || !keySecret) {
      // Demo mode – return mock order
      return NextResponse.json({
        orderId: "order_demo_" + Date.now(),
        amount: plan.amount,
        currency: "INR",
        keyId: "rzp_test_demo",
        planName: plan.name,
        demo: true,
      });
    }

    const auth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");

    const res = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${auth}`,
      },
      body: JSON.stringify({
        amount: plan.amount,
        currency: "INR",
        receipt: `rankai_${planId}_${Date.now()}`,
        notes: { planId },
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Razorpay error: ${err}`);
    }

    const order = await res.json();

    return NextResponse.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId,
      planName: plan.name,
      demo: false,
    });
  } catch (err: any) {
    console.error("Create order error:", err);
    return NextResponse.json(
      { error: err.message || "Failed to create order" },
      { status: 500 }
    );
  }
}
