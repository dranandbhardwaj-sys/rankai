import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// In-memory fallback when Supabase is not configured
const globalStore = globalThis as any;
if (!globalStore.__paymentClaims) {
  globalStore.__paymentClaims = [] as any[];
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { planId, planName, amount, upiNote, email, fullName } = body;

    if (!planId || !amount) {
      return NextResponse.json(
        { error: "planId and amount required" },
        { status: 400 }
      );
    }

    const claim = {
      plan_id: planId,
      plan_name: planName || planId,
      amount: Number(amount),
      upi_note: upiNote || null,
      email: email || null,
      full_name: fullName || null,
      status: "pending",
      created_at: new Date().toISOString(),
    };

    try {
      const supabase = await createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      const row = {
        ...claim,
        user_id: user?.id || null,
        email: email || user?.email || null,
      };

      const { data, error } = await supabase
        .from("payment_claims")
        .insert(row)
        .select()
        .single();

      if (error) throw error;

      return NextResponse.json({ success: true, claim: data, source: "database" });
    } catch {
      // Fallback: in-memory store (resets on server restart)
      const id = Date.now();
      const stored = { id, ...claim };
      globalStore.__paymentClaims.unshift(stored);
      return NextResponse.json({
        success: true,
        claim: stored,
        source: "memory",
        note: "Saved in memory (run 002_payment_claims.sql for persistent storage)",
      });
    }
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || "Failed to save claim" },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status") || "all";

  try {
    const supabase = await createClient();
    let query = supabase
      .from("payment_claims")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);

    if (status !== "all") {
      query = query.eq("status", status);
    }

    const { data, error } = await query;
    if (error) throw error;

    return NextResponse.json({
      claims: data || [],
      source: "database",
    });
  } catch {
    let list = globalStore.__paymentClaims || [];
    if (status !== "all") {
      list = list.filter((c: any) => c.status === status);
    }
    return NextResponse.json({
      claims: list,
      source: "memory",
    });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, status, adminNote } = body;

    if (!id || !["verified", "rejected", "pending"].includes(status)) {
      return NextResponse.json({ error: "Invalid id or status" }, { status: 400 });
    }

    try {
      const supabase = await createClient();
      const updates: any = {
        status,
        admin_note: adminNote || null,
      };
      if (status === "verified") {
        updates.verified_at = new Date().toISOString();
      }

      const { data, error } = await supabase
        .from("payment_claims")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return NextResponse.json({ success: true, claim: data, source: "database" });
    } catch {
      // Memory fallback
      const list = globalStore.__paymentClaims || [];
      const idx = list.findIndex((c: any) => c.id === id);
      if (idx === -1) {
        return NextResponse.json({ error: "Claim not found" }, { status: 404 });
      }
      list[idx] = {
        ...list[idx],
        status,
        admin_note: adminNote || null,
        verified_at:
          status === "verified" ? new Date().toISOString() : list[idx].verified_at,
      };
      return NextResponse.json({
        success: true,
        claim: list[idx],
        source: "memory",
      });
    }
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || "Update failed" },
      { status: 500 }
    );
  }
}
