import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// Fallback sample questions when DB is empty / not configured
const FALLBACK_QUESTIONS = [
  {
    id: 1,
    subject: "Physics",
    topic: "Current Electricity",
    difficulty: "medium",
    question_text:
      "Two resistors of 2Ω and 3Ω are connected in parallel. A 6V battery is connected across the combination. The current through the 2Ω resistor is:",
    options: { A: "1 A", B: "2 A", C: "3 A", D: "4 A" },
    correct_option: "C",
    explanation:
      "Voltage across both resistors is same (6V). Current through 2Ω = V/R = 6/2 = 3A.",
  },
  {
    id: 2,
    subject: "Chemistry",
    topic: "Chemical Kinetics",
    difficulty: "medium",
    question_text:
      "For a first order reaction, the half-life is 20 minutes. Time required for 75% completion is:",
    options: { A: "30 min", B: "40 min", C: "50 min", D: "60 min" },
    correct_option: "B",
    explanation:
      "For first order, half-life is constant. 75% completion means 25% left = 2 half-lives → 40 minutes.",
  },
  {
    id: 3,
    subject: "Maths",
    topic: "Calculus",
    difficulty: "easy",
    question_text: "The derivative of sin(x²) with respect to x is:",
    options: {
      A: "cos(x²)",
      B: "2x cos(x²)",
      C: "x cos(x²)",
      D: "2 cos(x²)",
    },
    correct_option: "B",
    explanation:
      "Using chain rule: d/dx [sin(u)] = cos(u) * du/dx where u = x² → 2x cos(x²).",
  },
  {
    id: 4,
    subject: "Physics",
    topic: "Current Electricity",
    difficulty: "easy",
    question_text: "The SI unit of electric current is:",
    options: { A: "Volt", B: "Ohm", C: "Ampere", D: "Coulomb" },
    correct_option: "C",
    explanation: "Electric current is measured in Ampere (A). 1A = 1 Coulomb/second.",
  },
  {
    id: 5,
    subject: "Biology",
    topic: "Neural Control",
    difficulty: "easy",
    question_text: "The resting membrane potential of a neuron is approximately:",
    options: { A: "+70 mV", B: "-70 mV", C: "0 mV", D: "+30 mV" },
    correct_option: "B",
    explanation:
      "Resting potential is about -70 mV (inside negative relative to outside).",
  },
];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const topicId = searchParams.get("topic_id");
  const difficulty = searchParams.get("difficulty");
  const limit = Number(searchParams.get("limit") || 10);
  const exam = searchParams.get("exam");

  try {
    const supabase = await createClient();

    let query = supabase
      .from("questions")
      .select(
        `
        id,
        question_text,
        options,
        correct_option,
        explanation,
        difficulty,
        exam_type,
        topics (
          topic_name,
          chapters (
            subject,
            chapter_name
          )
        )
      `
      )
      .limit(limit);

    if (topicId) query = query.eq("topic_id", topicId);
    if (difficulty) query = query.eq("difficulty", difficulty);
    if (exam) query = query.eq("exam_type", exam);

    const { data, error } = await query;

    if (error || !data || data.length === 0) {
      // Return fallback
      return NextResponse.json({
        questions: FALLBACK_QUESTIONS.slice(0, limit),
        source: "fallback",
      });
    }

    const formatted = data.map((q: any) => ({
      id: q.id,
      question_text: q.question_text,
      options: q.options,
      correct_option: q.correct_option,
      explanation: q.explanation,
      difficulty: q.difficulty,
      subject: q.topics?.chapters?.subject || "",
      topic: q.topics?.topic_name || "",
      chapter: q.topics?.chapters?.chapter_name || "",
    }));

    return NextResponse.json({ questions: formatted, source: "database" });
  } catch {
    return NextResponse.json({
      questions: FALLBACK_QUESTIONS.slice(0, limit),
      source: "fallback",
    });
  }
}
