"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Loader2,
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCw,
  Shield,
} from "lucide-react";

type Claim = {
  id: number;
  plan_id: string;
  plan_name?: string;
  amount: number;
  upi_note?: string;
  email?: string;
  full_name?: string;
  status: "pending" | "verified" | "rejected";
  admin_note?: string;
  created_at: string;
  verified_at?: string;
};

const ADMIN_PIN = "2649"; // simple gate – change later

export default function AdminPaymentsPage() {
  const [unlocked, setUnlocked] = useState(false);
  const [pin, setPin] = useState("");
  const [claims, setClaims] = useState<Claim[]>([]);
  const [filter, setFilter] = useState("pending");
  const [loading, setLoading] = useState(false);
  const [source, setSource] = useState("");
  const [actionId, setActionId] = useState<number | null>(null);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/payments/claims?status=${filter}`);
      const data = await res.json();
      setClaims(data.claims || []);
      setSource(data.source || "");
    } catch (e: any) {
      setError(e.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (unlocked) load();
  }, [unlocked, filter]);

  const updateStatus = async (id: number, status: "verified" | "rejected") => {
    setActionId(id);
    try {
      const res = await fetch("/api/payments/claims", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Update failed");
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setActionId(null);
    }
  };

  if (!unlocked) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-sm">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-blue-600" />
            <h1 className="font-bold text-lg">Admin – Payments</h1>
          </div>
          <p className="text-sm text-slate-500 mb-4">
            Enter PIN to view pending UPI claims
          </p>
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="PIN"
            className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm mb-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
            onKeyDown={(e) => {
              if (e.key === "Enter" && pin === ADMIN_PIN) setUnlocked(true);
            }}
          />
          <button
            onClick={() => {
              if (pin === ADMIN_PIN) setUnlocked(true);
              else setError("Wrong PIN");
            }}
            className="w-full bg-blue-600 text-white py-2.5 rounded-xl font-semibold hover:bg-blue-700"
          >
            Unlock
          </button>
          {error && (
            <p className="text-red-500 text-sm mt-2 text-center">{error}</p>
          )}
          <p className="text-[11px] text-slate-400 mt-4 text-center">
            Default PIN: last 4 digits of your UPI number (change in code)
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="p-2 hover:bg-slate-100 rounded-lg">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </Link>
          <div>
            <div className="font-semibold text-sm">Payment Claims</div>
            <div className="text-xs text-slate-500">
              UPI: 9162172649@ybl
              {source && (
                <span className="ml-2">
                  · {source === "database" ? "Live DB" : "Memory"}
                </span>
              )}
            </div>
          </div>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="p-2 hover:bg-slate-100 rounded-lg text-slate-500"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
        </button>
      </header>

      <div className="max-w-3xl mx-auto p-4">
        {/* Filters */}
        <div className="flex gap-2 mb-4 overflow-x-auto">
          {["pending", "verified", "rejected", "all"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize shrink-0 ${
                filter === f
                  ? "bg-blue-600 text-white"
                  : "bg-white border border-slate-200 text-slate-600"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl p-3 mb-4">
            {error}
          </div>
        )}

        {loading && claims.length === 0 ? (
          <div className="flex justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
          </div>
        ) : claims.length === 0 ? (
          <div className="text-center py-16 text-slate-500 text-sm">
            No {filter === "all" ? "" : filter} claims yet.
            <p className="text-xs mt-2 text-slate-400">
              Students jo “I have paid” dabayenge, yahan dikhenge.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {claims.map((c) => (
              <div
                key={c.id}
                className="bg-white border border-slate-200 rounded-xl p-4"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <div className="font-semibold text-slate-900 text-sm">
                      {c.plan_name || c.plan_id} · ₹{c.amount}
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {c.full_name || c.email || "Guest"} ·{" "}
                      {new Date(c.created_at).toLocaleString("en-IN")}
                    </div>
                  </div>
                  <StatusBadge status={c.status} />
                </div>

                {c.upi_note && (
                  <div className="text-xs bg-slate-50 rounded-lg px-2.5 py-1.5 text-slate-600 mb-3">
                    Note / UTR: <strong>{c.upi_note}</strong>
                  </div>
                )}

                {c.status === "pending" && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => updateStatus(c.id, "verified")}
                      disabled={actionId === c.id}
                      className="flex-1 bg-green-600 text-white py-2 rounded-lg text-xs font-semibold hover:bg-green-700 flex items-center justify-center gap-1 disabled:opacity-50"
                    >
                      {actionId === c.id ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      Verify
                    </button>
                    <button
                      onClick={() => updateStatus(c.id, "rejected")}
                      disabled={actionId === c.id}
                      className="flex-1 bg-red-50 text-red-600 border border-red-200 py-2 rounded-lg text-xs font-semibold hover:bg-red-100 flex items-center justify-center gap-1 disabled:opacity-50"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Reject
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  if (status === "verified") {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-green-50 text-green-700 px-2 py-0.5 rounded-full">
        <CheckCircle2 className="w-3 h-3" /> Verified
      </span>
    );
  }
  if (status === "rejected") {
    return (
      <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-red-50 text-red-600 px-2 py-0.5 rounded-full">
        <XCircle className="w-3 h-3" /> Rejected
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full">
      <Clock className="w-3 h-3" /> Pending
    </span>
  );
}
