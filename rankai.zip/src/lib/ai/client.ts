/**
 * Unified AI client – supports OpenAI and Anthropic (Claude)
 * Set AI_PROVIDER=openai or AI_PROVIDER=anthropic in .env.local
 */

type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

type AIResponse = {
  content: string;
  model: string;
  provider: string;
};

export async function callAI(
  messages: ChatMessage[],
  options: { temperature?: number; maxTokens?: number } = {}
): Promise<AIResponse> {
  const provider = (process.env.AI_PROVIDER || "openai").toLowerCase();
  const temperature = options.temperature ?? 0.4;
  const maxTokens = options.maxTokens ?? 1500;

  if (provider === "anthropic") {
    return callAnthropic(messages, temperature, maxTokens);
  }
  return callOpenAI(messages, temperature, maxTokens);
}

async function callOpenAI(
  messages: ChatMessage[],
  temperature: number,
  maxTokens: number
): Promise<AIResponse> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY is not set in environment variables");
  }

  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`OpenAI API error: ${res.status} – ${err}`);
  }

  const data = await res.json();
  return {
    content: data.choices?.[0]?.message?.content || "",
    model,
    provider: "openai",
  };
}

async function callAnthropic(
  messages: ChatMessage[],
  temperature: number,
  maxTokens: number
): Promise<AIResponse> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error("ANTHROPIC_API_KEY is not set in environment variables");
  }

  const model = process.env.ANTHROPIC_MODEL || "claude-3-5-sonnet-20241022";

  // Anthropic requires system message separately
  const systemMsg = messages.find((m) => m.role === "system")?.content || "";
  const userMessages = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    }));

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      temperature,
      system: systemMsg,
      messages: userMessages,
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Anthropic API error: ${res.status} – ${err}`);
  }

  const data = await res.json();
  const content =
    data.content?.map((c: any) => c.text).join("") || "";

  return {
    content,
    model,
    provider: "anthropic",
  };
}
