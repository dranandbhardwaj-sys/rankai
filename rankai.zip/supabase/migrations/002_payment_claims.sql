-- Payment claims (manual UPI verification)
create table if not exists public.payment_claims (
  id serial primary key,
  user_id uuid references public.profiles(id) on delete set null,
  email text,
  full_name text,
  plan_id text not null,
  plan_name text,
  amount integer not null,
  upi_note text,
  status text default 'pending' check (status in ('pending', 'verified', 'rejected')),
  admin_note text,
  created_at timestamptz default now(),
  verified_at timestamptz
);

create index if not exists idx_payment_claims_status on public.payment_claims(status);

alter table public.payment_claims enable row level security;

-- Anyone authenticated can insert their own claim
create policy "Users can insert claims"
  on public.payment_claims for insert
  with check (true);

-- Users can read own claims
create policy "Users can read own claims"
  on public.payment_claims for select
  using (
    auth.uid() = user_id
    or user_id is null
  );

-- For admin: use service role or loosen select for MVP
-- (In production, restrict admin by email/role)
create policy "Allow read all claims for admin MVP"
  on public.payment_claims for select
  using (true);

create policy "Allow update claims for admin MVP"
  on public.payment_claims for update
  using (true);
