-- RankAI Initial Schema
-- Run this in Supabase SQL Editor

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ======================
-- USERS (extends auth.users)
-- ======================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  exam_type text check (exam_type in ('jee_main', 'jee_advanced', 'neet')),
  class_level text check (class_level in ('11', '12', 'dropper')),
  target_score integer,
  daily_study_hours numeric(3,1) default 4,
  onboarding_completed boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ======================
-- SYLLABUS
-- ======================
create table public.chapters (
  id serial primary key,
  exam_type text not null,
  subject text not null, -- Physics, Chemistry, Maths, Biology
  chapter_name text not null,
  class_level text, -- 11, 12, or null for both
  order_index integer default 0,
  created_at timestamptz default now()
);

create table public.topics (
  id serial primary key,
  chapter_id integer references public.chapters(id) on delete cascade,
  topic_name text not null,
  importance_score integer default 3 check (importance_score between 1 and 5),
  created_at timestamptz default now()
);

-- ======================
-- USER PROGRESS
-- ======================
create table public.user_topic_progress (
  id serial primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  topic_id integer references public.topics(id) on delete cascade,
  status text default 'not_started' check (status in ('not_started', 'weak', 'average', 'strong')),
  accuracy numeric(5,2) default 0,
  questions_attempted integer default 0,
  last_practiced timestamptz,
  unique(user_id, topic_id)
);

-- ======================
-- QUESTIONS
-- ======================
create table public.questions (
  id serial primary key,
  topic_id integer references public.topics(id),
  exam_type text,
  difficulty text check (difficulty in ('easy', 'medium', 'hard')),
  question_text text not null,
  options jsonb, -- {"A": "...", "B": "...", "C": "...", "D": "..."}
  correct_option text, -- A, B, C, D
  explanation text,
  is_pyq boolean default false,
  year integer,
  source text,
  created_at timestamptz default now()
);

create index idx_questions_topic on public.questions(topic_id);
create index idx_questions_exam on public.questions(exam_type);

-- ======================
-- PRACTICE SESSIONS
-- ======================
create table public.practice_sessions (
  id serial primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  topic_id integer references public.topics(id),
  started_at timestamptz default now(),
  completed_at timestamptz,
  total_questions integer default 0,
  correct_count integer default 0
);

create table public.user_answers (
  id serial primary key,
  session_id integer references public.practice_sessions(id) on delete cascade,
  question_id integer references public.questions(id),
  selected_option text,
  is_correct boolean,
  time_taken_seconds integer,
  created_at timestamptz default now()
);

-- ======================
-- MOCK TESTS
-- ======================
create table public.mock_tests (
  id serial primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  exam_type text,
  title text,
  score integer,
  total_questions integer,
  time_taken_minutes integer,
  analysis jsonb, -- topic-wise breakdown + AI analysis
  created_at timestamptz default now()
);

-- ======================
-- DAILY PLANS
-- ======================
create table public.daily_plans (
  id serial primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  plan_date date not null,
  tasks jsonb not null, -- array of task objects
  generated_by text default 'ai',
  created_at timestamptz default now(),
  unique(user_id, plan_date)
);

-- ======================
-- DOUBT HISTORY (optional analytics)
-- ======================
create table public.doubt_logs (
  id serial primary key,
  user_id uuid references public.profiles(id) on delete cascade,
  question text not null,
  answer text,
  exam_type text,
  subject text,
  created_at timestamptz default now()
);

-- ======================
-- ROW LEVEL SECURITY
-- ======================
alter table public.profiles enable row level security;
alter table public.user_topic_progress enable row level security;
alter table public.practice_sessions enable row level security;
alter table public.user_answers enable row level security;
alter table public.mock_tests enable row level security;
alter table public.daily_plans enable row level security;
alter table public.doubt_logs enable row level security;

-- Profiles policies
create policy "Users can view own profile"
  on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);
create policy "Users can insert own profile"
  on public.profiles for insert with check (auth.uid() = id);

-- Progress policies
create policy "Users can manage own progress"
  on public.user_topic_progress for all using (auth.uid() = user_id);

-- Practice policies
create policy "Users can manage own practice"
  on public.practice_sessions for all using (auth.uid() = user_id);
create policy "Users can manage own answers"
  on public.user_answers for all using (
    auth.uid() = (select user_id from public.practice_sessions where id = session_id)
  );

-- Mock tests
create policy "Users can manage own mocks"
  on public.mock_tests for all using (auth.uid() = user_id);

-- Daily plans
create policy "Users can manage own plans"
  on public.daily_plans for all using (auth.uid() = user_id);

-- Doubt logs
create policy "Users can manage own doubts"
  on public.doubt_logs for all using (auth.uid() = user_id);

-- Public read for syllabus & questions
create policy "Anyone can read chapters"
  on public.chapters for select using (true);
create policy "Anyone can read topics"
  on public.topics for select using (true);
create policy "Anyone can read questions"
  on public.questions for select using (true);

-- ======================
-- TRIGGER: Auto-create profile on signup
-- ======================
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
