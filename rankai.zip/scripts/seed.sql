-- RankAI Seed Data
-- Run this AFTER 001_initial_schema.sql in Supabase SQL Editor

-- ======================
-- CHAPTERS (JEE Main + NEET common Physics & Chemistry)
-- ======================

-- Physics Class 11
insert into public.chapters (exam_type, subject, chapter_name, class_level, order_index) values
('jee_main', 'Physics', 'Units and Measurements', '11', 1),
('jee_main', 'Physics', 'Motion in a Straight Line', '11', 2),
('jee_main', 'Physics', 'Motion in a Plane', '11', 3),
('jee_main', 'Physics', 'Laws of Motion', '11', 4),
('jee_main', 'Physics', 'Work, Energy and Power', '11', 5),
('jee_main', 'Physics', 'System of Particles and Rotational Motion', '11', 6),
('jee_main', 'Physics', 'Gravitation', '11', 7),
('jee_main', 'Physics', 'Mechanical Properties of Solids', '11', 8),
('jee_main', 'Physics', 'Mechanical Properties of Fluids', '11', 9),
('jee_main', 'Physics', 'Thermal Properties of Matter', '11', 10),
('jee_main', 'Physics', 'Thermodynamics', '11', 11),
('jee_main', 'Physics', 'Kinetic Theory', '11', 12),
('jee_main', 'Physics', 'Oscillations', '11', 13),
('jee_main', 'Physics', 'Waves', '11', 14);

-- Physics Class 12
insert into public.chapters (exam_type, subject, chapter_name, class_level, order_index) values
('jee_main', 'Physics', 'Electric Charges and Fields', '12', 15),
('jee_main', 'Physics', 'Electrostatic Potential and Capacitance', '12', 16),
('jee_main', 'Physics', 'Current Electricity', '12', 17),
('jee_main', 'Physics', 'Moving Charges and Magnetism', '12', 18),
('jee_main', 'Physics', 'Magnetism and Matter', '12', 19),
('jee_main', 'Physics', 'Electromagnetic Induction', '12', 20),
('jee_main', 'Physics', 'Alternating Current', '12', 21),
('jee_main', 'Physics', 'Electromagnetic Waves', '12', 22),
('jee_main', 'Physics', 'Ray Optics and Optical Instruments', '12', 23),
('jee_main', 'Physics', 'Wave Optics', '12', 24),
('jee_main', 'Physics', 'Dual Nature of Radiation and Matter', '12', 25),
('jee_main', 'Physics', 'Atoms', '12', 26),
('jee_main', 'Physics', 'Nuclei', '12', 27),
('jee_main', 'Physics', 'Semiconductor Electronics', '12', 28);

-- Chemistry Class 11
insert into public.chapters (exam_type, subject, chapter_name, class_level, order_index) values
('jee_main', 'Chemistry', 'Some Basic Concepts of Chemistry', '11', 1),
('jee_main', 'Chemistry', 'Structure of Atom', '11', 2),
('jee_main', 'Chemistry', 'Classification of Elements', '11', 3),
('jee_main', 'Chemistry', 'Chemical Bonding', '11', 4),
('jee_main', 'Chemistry', 'States of Matter', '11', 5),
('jee_main', 'Chemistry', 'Thermodynamics', '11', 6),
('jee_main', 'Chemistry', 'Equilibrium', '11', 7),
('jee_main', 'Chemistry', 'Redox Reactions', '11', 8),
('jee_main', 'Chemistry', 'Hydrogen', '11', 9),
('jee_main', 'Chemistry', 'The s-Block Elements', '11', 10),
('jee_main', 'Chemistry', 'The p-Block Elements', '11', 11),
('jee_main', 'Chemistry', 'Organic Chemistry - Basic Principles', '11', 12),
('jee_main', 'Chemistry', 'Hydrocarbons', '11', 13),
('jee_main', 'Chemistry', 'Environmental Chemistry', '11', 14);

-- Chemistry Class 12
insert into public.chapters (exam_type, subject, chapter_name, class_level, order_index) values
('jee_main', 'Chemistry', 'The Solid State', '12', 15),
('jee_main', 'Chemistry', 'Solutions', '12', 16),
('jee_main', 'Chemistry', 'Electrochemistry', '12', 17),
('jee_main', 'Chemistry', 'Chemical Kinetics', '12', 18),
('jee_main', 'Chemistry', 'Surface Chemistry', '12', 19),
('jee_main', 'Chemistry', 'The d and f Block Elements', '12', 20),
('jee_main', 'Chemistry', 'Coordination Compounds', '12', 21),
('jee_main', 'Chemistry', 'Haloalkanes and Haloarenes', '12', 22),
('jee_main', 'Chemistry', 'Alcohols, Phenols and Ethers', '12', 23),
('jee_main', 'Chemistry', 'Aldehydes, Ketones and Carboxylic Acids', '12', 24),
('jee_main', 'Chemistry', 'Amines', '12', 25),
('jee_main', 'Chemistry', 'Biomolecules', '12', 26),
('jee_main', 'Chemistry', 'Polymers', '12', 27),
('jee_main', 'Chemistry', 'Chemistry in Everyday Life', '12', 28);

-- Maths (JEE only)
insert into public.chapters (exam_type, subject, chapter_name, class_level, order_index) values
('jee_main', 'Maths', 'Sets', '11', 1),
('jee_main', 'Maths', 'Relations and Functions', '11', 2),
('jee_main', 'Maths', 'Trigonometric Functions', '11', 3),
('jee_main', 'Maths', 'Complex Numbers', '11', 4),
('jee_main', 'Maths', 'Linear Inequalities', '11', 5),
('jee_main', 'Maths', 'Permutations and Combinations', '11', 6),
('jee_main', 'Maths', 'Binomial Theorem', '11', 7),
('jee_main', 'Maths', 'Sequences and Series', '11', 8),
('jee_main', 'Maths', 'Straight Lines', '11', 9),
('jee_main', 'Maths', 'Conic Sections', '11', 10),
('jee_main', 'Maths', 'Limits and Derivatives', '11', 11),
('jee_main', 'Maths', 'Statistics', '11', 12),
('jee_main', 'Maths', 'Probability', '11', 13),
('jee_main', 'Maths', 'Relations and Functions', '12', 14),
('jee_main', 'Maths', 'Inverse Trigonometric Functions', '12', 15),
('jee_main', 'Maths', 'Matrices', '12', 16),
('jee_main', 'Maths', 'Determinants', '12', 17),
('jee_main', 'Maths', 'Continuity and Differentiability', '12', 18),
('jee_main', 'Maths', 'Application of Derivatives', '12', 19),
('jee_main', 'Maths', 'Integrals', '12', 20),
('jee_main', 'Maths', 'Application of Integrals', '12', 21),
('jee_main', 'Maths', 'Differential Equations', '12', 22),
('jee_main', 'Maths', 'Vector Algebra', '12', 23),
('jee_main', 'Maths', 'Three Dimensional Geometry', '12', 24),
('jee_main', 'Maths', 'Probability', '12', 25);

-- Biology (NEET)
insert into public.chapters (exam_type, subject, chapter_name, class_level, order_index) values
('neet', 'Biology', 'The Living World', '11', 1),
('neet', 'Biology', 'Biological Classification', '11', 2),
('neet', 'Biology', 'Plant Kingdom', '11', 3),
('neet', 'Biology', 'Animal Kingdom', '11', 4),
('neet', 'Biology', 'Morphology of Flowering Plants', '11', 5),
('neet', 'Biology', 'Anatomy of Flowering Plants', '11', 6),
('neet', 'Biology', 'Structural Organisation in Animals', '11', 7),
('neet', 'Biology', 'Cell: The Unit of Life', '11', 8),
('neet', 'Biology', 'Biomolecules', '11', 9),
('neet', 'Biology', 'Cell Cycle and Cell Division', '11', 10),
('neet', 'Biology', 'Transport in Plants', '11', 11),
('neet', 'Biology', 'Mineral Nutrition', '11', 12),
('neet', 'Biology', 'Photosynthesis in Higher Plants', '11', 13),
('neet', 'Biology', 'Respiration in Plants', '11', 14),
('neet', 'Biology', 'Plant Growth and Development', '11', 15),
('neet', 'Biology', 'Digestion and Absorption', '11', 16),
('neet', 'Biology', 'Breathing and Exchange of Gases', '11', 17),
('neet', 'Biology', 'Body Fluids and Circulation', '11', 18),
('neet', 'Biology', 'Excretory Products and their Elimination', '11', 19),
('neet', 'Biology', 'Locomotion and Movement', '11', 20),
('neet', 'Biology', 'Neural Control and Coordination', '11', 21),
('neet', 'Biology', 'Chemical Coordination and Integration', '11', 22),
('neet', 'Biology', 'Reproduction in Organisms', '12', 23),
('neet', 'Biology', 'Sexual Reproduction in Flowering Plants', '12', 24),
('neet', 'Biology', 'Human Reproduction', '12', 25),
('neet', 'Biology', 'Reproductive Health', '12', 26),
('neet', 'Biology', 'Principles of Inheritance and Variation', '12', 27),
('neet', 'Biology', 'Molecular Basis of Inheritance', '12', 28),
('neet', 'Biology', 'Evolution', '12', 29),
('neet', 'Biology', 'Human Health and Disease', '12', 30),
('neet', 'Biology', 'Strategies for Enhancement in Food Production', '12', 31),
('neet', 'Biology', 'Microbes in Human Welfare', '12', 32),
('neet', 'Biology', 'Biotechnology: Principles and Processes', '12', 33),
('neet', 'Biology', 'Biotechnology and its Applications', '12', 34),
('neet', 'Biology', 'Organisms and Populations', '12', 35),
('neet', 'Biology', 'Ecosystem', '12', 36),
('neet', 'Biology', 'Biodiversity and Conservation', '12', 37),
('neet', 'Biology', 'Environmental Issues', '12', 38);

-- Also add Physics & Chemistry for NEET (same chapters)
insert into public.chapters (exam_type, subject, chapter_name, class_level, order_index)
select 'neet', subject, chapter_name, class_level, order_index
from public.chapters
where exam_type = 'jee_main' and subject in ('Physics', 'Chemistry');

-- ======================
-- SAMPLE TOPICS (for Current Electricity as example)
-- ======================
insert into public.topics (chapter_id, topic_name, importance_score)
select id, 'Electric Current and Drift Velocity', 4
from public.chapters where chapter_name = 'Current Electricity' and exam_type = 'jee_main' limit 1;

insert into public.topics (chapter_id, topic_name, importance_score)
select id, 'Ohm''s Law and Resistance', 5
from public.chapters where chapter_name = 'Current Electricity' and exam_type = 'jee_main' limit 1;

insert into public.topics (chapter_id, topic_name, importance_score)
select id, 'Kirchhoff''s Laws', 5
from public.chapters where chapter_name = 'Current Electricity' and exam_type = 'jee_main' limit 1;

insert into public.topics (chapter_id, topic_name, importance_score)
select id, 'Wheatstone Bridge and Meter Bridge', 4
from public.chapters where chapter_name = 'Current Electricity' and exam_type = 'jee_main' limit 1;

insert into public.topics (chapter_id, topic_name, importance_score)
select id, 'Potentiometer', 3
from public.chapters where chapter_name = 'Current Electricity' and exam_type = 'jee_main' limit 1;

insert into public.topics (chapter_id, topic_name, importance_score)
select id, 'Heating Effect of Current', 3
from public.chapters where chapter_name = 'Current Electricity' and exam_type = 'jee_main' limit 1;

-- ======================
-- SAMPLE QUESTIONS
-- ======================
insert into public.questions (topic_id, exam_type, difficulty, question_text, options, correct_option, explanation, is_pyq, year)
select 
  t.id,
  'jee_main',
  'medium',
  'Two resistors of 2Ω and 3Ω are connected in parallel. A 6V battery is connected across the combination. The current through the 2Ω resistor is:',
  '{"A": "1 A", "B": "2 A", "C": "3 A", "D": "4 A"}',
  'C',
  'Voltage across both resistors is same (6V). Current through 2Ω = V/R = 6/2 = 3A.',
  false,
  null
from public.topics t
where t.topic_name = 'Ohm''s Law and Resistance'
limit 1;

insert into public.questions (topic_id, exam_type, difficulty, question_text, options, correct_option, explanation, is_pyq, year)
select 
  t.id,
  'jee_main',
  'hard',
  'In a Kirchhoff''s law application, the algebraic sum of all the currents meeting at a junction is:',
  '{"A": "Zero", "B": "Positive", "C": "Negative", "D": "Infinite"}',
  'A',
  'Kirchhoff''s Current Law (KCL) states that the algebraic sum of currents at a junction is zero (charge conservation).',
  true,
  2021
from public.topics t
where t.topic_name = 'Kirchhoff''s Laws'
limit 1;

insert into public.questions (topic_id, exam_type, difficulty, question_text, options, correct_option, explanation, is_pyq, year)
select 
  t.id,
  'jee_main',
  'easy',
  'The SI unit of electric current is:',
  '{"A": "Volt", "B": "Ohm", "C": "Ampere", "D": "Coulomb"}',
  'C',
  'Electric current is measured in Ampere (A). 1 Ampere = 1 Coulomb/second.',
  false,
  null
from public.topics t
where t.topic_name = 'Electric Current and Drift Velocity'
limit 1;

insert into public.questions (topic_id, exam_type, difficulty, question_text, options, correct_option, explanation, is_pyq, year)
select 
  t.id,
  'jee_main',
  'medium',
  'For a first order reaction, the half-life is 20 minutes. Time required for 75% completion is:',
  '{"A": "30 min", "B": "40 min", "C": "50 min", "D": "60 min"}',
  'B',
  'For first order, half-life is constant. 75% completion means 25% left = 2 half-lives → 40 minutes.',
  true,
  2020
from public.topics t
where t.topic_name like '%Kinetics%' or t.topic_name like '%Ohm%'
limit 1;

-- Add a few more generic questions linked to first available topic
insert into public.questions (topic_id, exam_type, difficulty, question_text, options, correct_option, explanation, is_pyq)
select 
  (select id from public.topics limit 1),
  'jee_main',
  'medium',
  'The dimensional formula of resistance is:',
  '{"A": "[ML²T⁻³A⁻²]", "B": "[ML²T⁻²A⁻²]", "C": "[MLT⁻³A⁻²]", "D": "[ML²T⁻³A⁻¹]"}',
  'A',
  'R = V/I = (W/Q)/I. Using dimensions of work, charge and current we get [ML²T⁻³A⁻²].',
  false;

insert into public.questions (topic_id, exam_type, difficulty, question_text, options, correct_option, explanation, is_pyq)
select 
  (select id from public.topics limit 1),
  'neet',
  'easy',
  'The resting membrane potential of a neuron is approximately:',
  '{"A": "+70 mV", "B": "-70 mV", "C": "0 mV", "D": "+30 mV"}',
  'B',
  'Resting potential is about -70 mV (inside negative relative to outside).',
  false;

-- Done
select 'Seed completed successfully!' as status;
select count(*) as total_chapters from public.chapters;
select count(*) as total_topics from public.topics;
select count(*) as total_questions from public.questions;
