# How to Seed RankAI Database

## Step 1: Create Supabase Project
1. Go to https://supabase.com → New Project
2. Note down **Project URL** and **anon key**

## Step 2: Run Schema
1. Open Supabase Dashboard → SQL Editor
2. Paste contents of `supabase/migrations/001_initial_schema.sql`
3. Click **Run**

## Step 3: Seed Data
1. Still in SQL Editor → New query
2. Paste contents of `scripts/seed.sql`
3. Click **Run**

You should see:
- total_chapters
- total_topics  
- total_questions

## Step 4: Configure App
```bash
cp .env.example .env.local
```

Fill:
```
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
AI_PROVIDER=openai
OPENAI_API_KEY=sk-...
```

## Step 5: Enable Email Auth (optional)
Supabase Dashboard → Authentication → Providers → Email → Enable

## Verify
```bash
npm run dev
```
- Go to /login → Create account
- Complete onboarding
- Profile should be saved in `profiles` table
